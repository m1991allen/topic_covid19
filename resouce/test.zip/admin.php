<?php
    file_put_contents(__DIR__.'/content.txt', $_POST);
?>
