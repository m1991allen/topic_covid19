// scrollspy
$(document).ready(function () {
    $(window).on('load scroll resize', function () {

        var docHeight = $(document).height();
        var windowPos = $(window).scrollTop();
        var windowHeight = $(window).height();
        var windowWidth = $(window).width();
        var completion = windowPos / (docHeight - windowHeight);

        if (docHeight <= windowHeight) {
            $('#progress').width(windowWidth);
        } else {
            $('#progress').width(completion * windowWidth);
        }
    });
    // scrolltop
    $('#BackTop').click(function (event) {
        console.log(1);
        $('html, body').animate({
            scrollTop: 0
        }, '1000');
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() < 100) { //判斷捲軸小於200座標位置時，消失
            $('#BackTop').stop().fadeOut('fast');
        } else {
            $('#BackTop').stop().fadeIn('fast'); //stop()可以讓使用者停止
        }
    });
    //
    $("#worldTabs").tabs();
});



//chinaMap
(function ($) {
    "use strict";
    $(function () {
        var $svgEl = $('.map_china');
        $('.map_china__trigger a').on('click', function (e) {

            // stop propagation of this event, it will never reach body in bubbling phase.
            e.stopPropagation();

            var goName = $(this).data('title'),
                goText = $(this).text(),
                svgCurName = '',
                svgNameIndex = 0;

            $('.map_china .map_china__name').each(function () {

                if (goName == $(this).data('title')) {
                    svgCurName = $(this).data('title');
                    return false;
                }
            });

            svgNameIndex = $('.map_china .map_china__name[data-title="' + svgCurName + '"]').index();

            //Hide all elements
            svgMapRestore(1);


            //Display current element
            svgMapActive(svgNameIndex, goText);
        });


        //Restore all elements
        $('body').on('click', function (e) {
            svgMapRestore(2);
        });

        function svgMapRestore(type) {

            var alpha = (type == 1) ? 0.3 : 1;

            $svgEl.children().removeClass('is-show');
            $svgEl.find('circle').css({
                'r': 6,
                // 'font-size': 'r1em',
                'z-index': 1,
                'opacity': alpha
            });


            $svgEl.find('.map_china__name').each(function () {
                $(this).css({
                    'transform': 'translate(0,15px)',
                    'z-index': 1,
                    'opacity': alpha
                })
                    .text($(this).data('title'));
            });

            $svgEl.find('.map_china__num').css({
                // 'font-size': '1rem',
                'z-index': 1,
                'opacity': alpha
            });
        }

        function svgMapActive(index, text) {
            $svgEl.each(function () {
                $(this).children().eq(index).addClass('is-show');
                $(this).find('circle').eq(index).css({
                    'r': 15,
                    'z-index': 2,
                    'opacity': 1
                });

                $(this).find('.map_china__name').eq(index).css({
                    'transform': 'translate(0,25px)',
                    'z-index': 2,
                    'opacity': 1
                })
                    .text(text);

                $(this).find('.map_china__num').eq(index).css({
                    // 'font-size': '1rem',
                    'z-index': 2,
                    'opacity': 1
                });
            });
        }
    });
})(jQuery);



// worldMap
$("path").mouseenter(function (e) {
    $(".hovertext").text($(this).attr('title'));
    $(".hovertext").css({
        'top': e.pageY - 20,
        'left': e.pageX,
    }).fadeIn('1000');
});
$("circle").mouseenter(function (e) {
    $(".hovertext").text($(this).attr('title'));
    $(".hovertext").css({
        'top': e.pageY - 20,
        'left': e.pageX,
    }).fadeIn('1000');
});


// line chart
var ctx = document.getElementById('chinaLineChart').getContext('2d');
var myLineChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['1/14', '1/17', '1/21', '1/25', '1/29', '2/2', '2/6'],
        datasets: [{
            label: '死亡',
            data: [10, 130, 140, 200, 300, 500, 1000],
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            pointBackgroundColor: 'rgba(0, 0, 0, 0.1)',
            borderWidth: 1
        }, {
            label: '治癒',
            data: [20, 140, 150, 210, 400, 900, 1550],
            backgroundColor: 'rgba(184, 178, 178, 0.2)',
            borderColor: 'rgba(184, 178, 178,1)',
            pointBackgroundColor: 'rgba(0, 0, 0, 0.1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    fontSize: 16
                }
            }],
            xAxes: [{
                ticks: {
                    fontSize: 16
                }
            }],
        }
    }
});

